
import './App.css';

import React from 'react';
import LoginForm from './components/LoginForm';
import Dashboard from './components/Dashboard';
import Navigator from './components/Navigator';

class App extends React.Component {

  state = {
    text: '',
    isLoggedIn: false,
  };

  updateData = (value) => {
    this.setState({ text: value })
  }

  handleLoginClick = (param) => {
    this.setState({ isLoggedIn: param });
  }

  render() {
    return <div className="App">
      {this.state.isLoggedIn ?
        <div className="MainScreen">
          <Navigator updateData={this.updateData} />
          <Dashboard handleLoginClick={this.handleLoginClick}
            text={this.state.text} />
        </div> : <LoginForm handleLoginClick={this.handleLoginClick} />}
    </div>;
  }
}

export default App;
