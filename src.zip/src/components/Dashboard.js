import React from 'react';



export default class Dashboard extends React.Component {
  handlClick = () => {
    const { handleLoginClick } = this.props;
    handleLoginClick(false);
  }

  render() {
    console.log(this.props.text);
    return (

      <div className="dashboard"> Dashboard
        <button onClick={this.handlClick} className="buttonExit"> Выйти </button>

        <div className="FIO">

          {this.props.text}


        </div>

      </div>


    );
  }
}

