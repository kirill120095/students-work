import React from 'react';
import PersonIcon from '@material-ui/icons/Person';
import PeopleOutlineIcon from '@material-ui/icons/PeopleOutline';
import DateRangeIcon from '@material-ui/icons/DateRange';
import { render } from '@testing-library/react';
import { Button } from '@material-ui/core';

export default class Navigator extends React.Component {
  state = {
    name: 'Филимонов Кирилл Константинович',
    group: 'ИВТ-11-17',
    age: '21'
  }
  render() {
  
    return <div className=" navigator">

<button  className=" buttonInput" onClick={() => { this.props.updateData(this.state.name)}}> <PersonIcon />ФИО </button>
<button className=" buttonInput"onClick={() => { this.props.updateData(this.state.group)}}> <PeopleOutlineIcon />Группа</button>
<button className=" buttonInput"onClick={() => { this.props.updateData(this.state.age)}}><DateRangeIcon />Возраст</button>

    </div>

  }
}

